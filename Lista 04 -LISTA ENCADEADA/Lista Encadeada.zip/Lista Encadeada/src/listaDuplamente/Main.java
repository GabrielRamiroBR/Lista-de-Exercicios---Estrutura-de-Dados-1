package listaDuplamente;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		ListaDuplamente lista = new ListaDuplamente();
		TesteListaDuplamente teste = new TesteListaDuplamente();
		
		teste.valida(lista);
	}
}