package listaSingular;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Lista lista = new Lista();
		TesteListaSingular teste = new TesteListaSingular();
		
		teste.valida(lista);
	}
}